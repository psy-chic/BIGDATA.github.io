"""
Exploratory analysis of the synthetic 5-stock dataset:
- Price trends over time
- Daily & cumulative returns
- Volatility (rolling std, annualized)
- Correlation between stocks
- Risk/return summary (Sharpe-like ratio, max drawdown)
- Volume patterns
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_theme(style="whitegrid", palette="deep")
plt.rcParams["figure.dpi"] = 110

df = pd.read_csv("/home/claude/stock_project/synthetic_stock_data.csv", parse_dates=["date"])
tickers = sorted(df["ticker"].unique())
sectors = df.drop_duplicates("ticker").set_index("ticker")["sector"].to_dict()

# Pivot to wide format: date x ticker close price
close = df.pivot(index="date", columns="ticker", values="close").sort_index()
volume = df.pivot(index="date", columns="ticker", values="volume").sort_index()

# ---------- Daily & cumulative returns ----------
daily_returns = close.pct_change().dropna()
cumulative_returns = (1 + daily_returns).cumprod() - 1

# ---------- Summary stats ----------
TRADING_DAYS = 252
summary = pd.DataFrame(index=tickers)
summary["Sector"] = [sectors[t] for t in tickers]
summary["Start Price"] = close.iloc[0]
summary["End Price"] = close.iloc[-1]
summary["Total Return %"] = ((close.iloc[-1] / close.iloc[0]) - 1) * 100
summary["Ann. Return %"] = daily_returns.mean() * TRADING_DAYS * 100
summary["Ann. Volatility %"] = daily_returns.std() * np.sqrt(TRADING_DAYS) * 100
summary["Sharpe (rf=0)"] = summary["Ann. Return %"] / summary["Ann. Volatility %"]

# Max drawdown
def max_drawdown(price_series):
    running_max = price_series.cummax()
    drawdown = (price_series - running_max) / running_max
    return drawdown.min() * 100

summary["Max Drawdown %"] = close.apply(max_drawdown)
summary["Avg Daily Volume"] = volume.mean().astype(int)

summary = summary.round(2)
summary.to_csv("/home/claude/stock_project/summary_stats.csv")
print("=== Summary Statistics ===")
print(summary.to_string())
print()

# ---------- Correlation matrix ----------
corr_matrix = daily_returns.corr().round(3)
corr_matrix.to_csv("/home/claude/stock_project/correlation_matrix.csv")
print("=== Return Correlation Matrix ===")
print(corr_matrix.to_string())
print()

# ==================== FIGURES ====================

# Fig 1: Price trends (normalized to 100 at start for fair comparison)
normalized = close / close.iloc[0] * 100
fig, ax = plt.subplots(figsize=(11, 6))
for t in tickers:
    ax.plot(normalized.index, normalized[t], label=f"{t} ({sectors[t]})", linewidth=1.6)
ax.set_title("Normalized Price Performance (Start = 100)", fontsize=14, fontweight="bold")
ax.set_xlabel("Date")
ax.set_ylabel("Indexed Price")
ax.legend(loc="upper left", fontsize=9)
ax.axhline(100, color="gray", linestyle="--", linewidth=0.8, alpha=0.6)
fig.tight_layout()
fig.savefig("/home/claude/stock_project/fig1_price_trends.png")
plt.close(fig)

# Fig 2: Cumulative returns
fig, ax = plt.subplots(figsize=(11, 6))
for t in tickers:
    ax.plot(cumulative_returns.index, cumulative_returns[t] * 100, label=t, linewidth=1.6)
ax.set_title("Cumulative Returns Over Time", fontsize=14, fontweight="bold")
ax.set_xlabel("Date")
ax.set_ylabel("Cumulative Return (%)")
ax.legend(loc="upper left", fontsize=9)
ax.axhline(0, color="gray", linestyle="--", linewidth=0.8, alpha=0.6)
fig.tight_layout()
fig.savefig("/home/claude/stock_project/fig2_cumulative_returns.png")
plt.close(fig)

# Fig 3: Rolling 30-day annualized volatility
rolling_vol = daily_returns.rolling(30).std() * np.sqrt(TRADING_DAYS) * 100
fig, ax = plt.subplots(figsize=(11, 6))
for t in tickers:
    ax.plot(rolling_vol.index, rolling_vol[t], label=t, linewidth=1.4)
ax.set_title("30-Day Rolling Annualized Volatility", fontsize=14, fontweight="bold")
ax.set_xlabel("Date")
ax.set_ylabel("Annualized Volatility (%)")
ax.legend(loc="upper left", fontsize=9)
fig.tight_layout()
fig.savefig("/home/claude/stock_project/fig3_rolling_volatility.png")
plt.close(fig)

# Fig 4: Correlation heatmap
fig, ax = plt.subplots(figsize=(7, 6))
sns.heatmap(corr_matrix, annot=True, cmap="coolwarm", center=0, vmin=-1, vmax=1,
            square=True, linewidths=0.5, ax=ax, cbar_kws={"label": "Correlation"})
ax.set_title("Daily Return Correlation Between Stocks", fontsize=13, fontweight="bold")
fig.tight_layout()
fig.savefig("/home/claude/stock_project/fig4_correlation_heatmap.png")
plt.close(fig)

# Fig 5: Risk-return scatter
fig, ax = plt.subplots(figsize=(8, 6))
colors = sns.color_palette("deep", len(tickers))
for i, t in enumerate(tickers):
    ax.scatter(summary.loc[t, "Ann. Volatility %"], summary.loc[t, "Ann. Return %"],
               s=180, color=colors[i], edgecolor="black", linewidth=1, zorder=3)
    ax.annotate(t, (summary.loc[t, "Ann. Volatility %"], summary.loc[t, "Ann. Return %"]),
                textcoords="offset points", xytext=(8, 6), fontsize=10, fontweight="bold")
ax.set_title("Risk vs. Return by Stock", fontsize=14, fontweight="bold")
ax.set_xlabel("Annualized Volatility (%)")
ax.set_ylabel("Annualized Return (%)")
ax.axhline(0, color="gray", linestyle="--", linewidth=0.8, alpha=0.6)
fig.tight_layout()
fig.savefig("/home/claude/stock_project/fig5_risk_return_scatter.png")
plt.close(fig)

# Fig 6: Daily returns distribution (small multiples)
fig, axes = plt.subplots(2, 3, figsize=(14, 8))
axes = axes.flatten()
for i, t in enumerate(tickers):
    sns.histplot(daily_returns[t] * 100, bins=50, kde=True, ax=axes[i], color=colors[i])
    axes[i].set_title(f"{t} Daily Returns", fontsize=11, fontweight="bold")
    axes[i].set_xlabel("Daily Return (%)")
    axes[i].axvline(0, color="gray", linestyle="--", linewidth=0.8)
axes[-1].axis("off")
fig.suptitle("Distribution of Daily Returns by Stock", fontsize=14, fontweight="bold")
fig.tight_layout()
fig.savefig("/home/claude/stock_project/fig6_return_distributions.png")
plt.close(fig)

print("All figures saved to /home/claude/stock_project/")
