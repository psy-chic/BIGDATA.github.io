"""
Generates realistic SYNTHETIC daily stock price data for 5 companies across
different sectors, over 3 years. This is NOT real market data — it's built
using geometric Brownian motion calibrated to plausible real-world parameters
(annual drift, annual volatility) with a realistic cross-stock correlation
structure, occasional volatility shocks, and weekday-only trading calendar.
"""

import numpy as np
import pandas as pd

np.random.seed(42)

# ---- Configuration ----
START_DATE = "2023-01-03"
END_DATE = "2025-12-31"
TRADING_DAYS_PER_YEAR = 252

# Ticker: (sector, starting_price, annual_drift, annual_volatility)
# Parameters are plausible/representative, not fitted to real historical data.
TICKERS = {
    "TCHX": ("Technology",   150.00, 0.18, 0.32),   # high-growth tech
    "BNKF": ("Financials",    45.00, 0.08, 0.24),   # bank
    "HLTC": ("Healthcare",   110.00, 0.10, 0.20),   # healthcare
    "ENRG": ("Energy",        60.00, 0.05, 0.35),   # energy, volatile
    "CNSM": ("Consumer",      75.00, 0.09, 0.18),   # consumer staples, stable
}

# Correlation matrix between the 5 stocks' daily returns (symmetric, realistic-ish)
corr = np.array([
    [1.00, 0.35, 0.25, 0.20, 0.30],
    [0.35, 1.00, 0.30, 0.25, 0.35],
    [0.25, 0.30, 1.00, 0.15, 0.25],
    [0.20, 0.25, 0.15, 1.00, 0.20],
    [0.30, 0.35, 0.25, 0.20, 1.00],
])

tickers = list(TICKERS.keys())
n_assets = len(tickers)

# Business-day trading calendar
dates = pd.bdate_range(START_DATE, END_DATE)
n_days = len(dates)

# Daily drift/vol from annualized parameters
mu = np.array([TICKERS[t][2] for t in tickers]) / TRADING_DAYS_PER_YEAR
sigma = np.array([TICKERS[t][3] for t in tickers]) / np.sqrt(TRADING_DAYS_PER_YEAR)

# Correlated random shocks via Cholesky decomposition
L = np.linalg.cholesky(corr)
Z = np.random.normal(size=(n_days, n_assets))
correlated_Z = Z @ L.T

# Inject a couple of shared market shock events (e.g. broad selloffs) for realism
shock_days = np.random.choice(n_days, size=4, replace=False)
for sd in shock_days:
    shock_magnitude = np.random.uniform(-0.06, -0.03)
    correlated_Z[sd] += shock_magnitude / sigma  # translate price shock into z-units

# Simulate log returns: r = mu - 0.5*sigma^2 + sigma*Z
log_returns = (mu - 0.5 * sigma**2) + sigma * correlated_Z

records = []
for i, t in enumerate(tickers):
    sector, start_price, _, _ = TICKERS[t]
    prices = start_price * np.exp(np.cumsum(log_returns[:, i]))
    prices = np.insert(prices, 0, start_price)[:-1]  # start at start_price on day 0

    # Simulate volume: base volume with noise, higher on big move days
    base_vol = np.random.uniform(3_000_000, 12_000_000)
    daily_move = np.abs(log_returns[:, i])
    volume = (base_vol * (1 + 5 * daily_move) * np.random.uniform(0.7, 1.3, n_days)).astype(int)

    # Simple OHLC approximation around close
    close = prices
    open_ = close * (1 + np.random.normal(0, 0.003, n_days))
    high = np.maximum(open_, close) * (1 + np.abs(np.random.normal(0, 0.004, n_days)))
    low = np.minimum(open_, close) * (1 - np.abs(np.random.normal(0, 0.004, n_days)))

    for d in range(n_days):
        records.append({
            "date": dates[d],
            "ticker": t,
            "sector": sector,
            "open": round(open_[d], 2),
            "high": round(high[d], 2),
            "low": round(low[d], 2),
            "close": round(close[d], 2),
            "volume": volume[d],
        })

df = pd.DataFrame.from_records(records)
df = df.sort_values(["ticker", "date"]).reset_index(drop=True)

out_path = "/home/claude/stock_project/synthetic_stock_data.csv"
df.to_csv(out_path, index=False)
print(f"Generated {len(df):,} rows across {n_assets} tickers, {n_days} trading days.")
print(f"Saved to {out_path}")
print(df.head(8))
